Chapter 6 Programs



wireSphere: wire frame of recursively generated sphere

shadedCube: rotating cube with modified Phong shading

Phong illumination model

shadedSphere1: shaded sphere using true normals and per vertex shading (Gouraud shading )

shadedSphere2: shaded sphere using true normals and per fragment shading (Phong shading)

shadedSphere3: shaded sphere using approximated normals and per vertex shading (Gouraud shading )

shadedSphere4: shaded sphere using approximated normals and per fragment shading (Phong shading)
