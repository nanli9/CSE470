Texture Mapping Programs:



textureCube1: 
texture map of a gif image onto cube. Note some browsers such as Chrome will not allow the use of an external file as texture image, so use Firefox. Program also displays the image on the right.



textureCubev2: texture mapping checkerboard onto cube



textureCubev3: 
texture map onto cube using two texture images multiplied together in fragment shader



textureCube4: 
texture map with two texture units. First applies checkerboard, second a sinusoid.



textureSquare: 
demo of aliasing with different  texture parameters.

hatImage: 
sombrero function y-values assigned colors to create a texture, which is then mapped to a square
Creates color in frag shader
Example of scientific data used to create texture.

Hawaii:
image display of height data from hawaii using a texture map with edge enhancement in the fragment.
Accessing texture and doing own sampling.
Edge enhancement using a mask  -1  1 in x and -1 1 in y with 10 to enhance colors
 


